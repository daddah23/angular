import { Component, OnInit } from '@angular/core';
import { Etudiant } from 'src/app/models/etudiant';
import { Filiere } from 'src/app/models/filiere';
import { EtudiantService } from 'src/app/services/etudiant.service';
import { FiliereService } from 'src/app/services/filiere.service';

@Component({
  selector: 'app-list-filiere',
  templateUrl: './list-filiere.component.html',
  styleUrls: ['./list-filiere.component.css']
})
export class ListFiliereComponent implements OnInit{

  filieres: Filiere[] = []; // Liste des filières
  etudiants: Etudiant[] = []; // Liste des étudiants d'une filière
  filiereId: number | null = null; // ID de la filière saisie par l'utilisateur

  constructor(
    private filiereService: FiliereService,
    private etudiantService: EtudiantService
  ) { }

  ngOnInit(): void {
    this.loadFilieres(); // Charger la liste des filières au démarrage
  }

  // Charger toutes les filières
  loadFilieres(): void {
    this.filiereService.getAllFiliere().subscribe(
      (data) => this.filieres = data,
      (error) => console.error('Erreur lors du chargement des filières', error)
    );
  }
  deleteFiliere(id:any){
    if (confirm("merci de confirmer la suppression de la filiere")) {

      this.filiereService.deleteFiliere(id).subscribe(
        () => {
          console.log('Filiere supprimé');
          this.ngOnInit();
        },
        (error) => console.error('Erreur lors de la suppression ', error)
      );

    }
  }

  // Charger les étudiants d'une filière spécifique
  loadEtudiantsByFiliere(): void {
    if (this.filiereId !== null) {
      this.etudiantService.getEtudiantByFiliere(this.filiereId).subscribe(
        (data) => this.etudiants = data,
        (error) => console.error('Erreur lors du chargement des étudiants', error)
      );
    } else {
      this.etudiants = []; // Réinitialiser la liste si aucun ID n'est saisi
    }
  }
}
