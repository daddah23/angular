import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListFiliereComponent } from './list-filiere.component';

describe('ListFiliereComponent', () => {
  let component: ListFiliereComponent;
  let fixture: ComponentFixture<ListFiliereComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ListFiliereComponent]
    });
    fixture = TestBed.createComponent(ListFiliereComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
