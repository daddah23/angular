import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Etudiant } from 'src/app/models/etudiant';
import { EtudiantService } from 'src/app/services/etudiant.service';

@Component({
  selector: 'app-list-etudiant',
  templateUrl: './list-etudiant.component.html',
  styleUrls: ['./list-etudiant.component.css']
})
export class ListEtudiantComponent implements OnInit {

  etudiants:Etudiant[]=[]

  constructor(private etudiantService:EtudiantService,private router:Router){

  }
  ngOnInit(): void {

    this.etudiantService.getAllEtudiant().subscribe((data)=>{
      this.etudiants=data
    },(err)=>{
      console.log(err)
    })
  }

  navigerVersAddForm(){
    this.router.navigate(['/etudiants/add'])
  }
  navigerVersFiliere(){
    this.router.navigate(['/filieres'])
  }

  deleteEtudiant(id:any): void {
    if (confirm("merci de confirmer la suppression de l'etudiant")) {

      this.etudiantService.deleteEtudiant(id).subscribe(
        () => {
          console.log('Étudiant supprimé');
          this.ngOnInit(); // Recharger la liste après la suppression
        },
        (error) => console.error('Erreur lors de la suppression de l\'étudiant', error)
      );

    }

  }




}
