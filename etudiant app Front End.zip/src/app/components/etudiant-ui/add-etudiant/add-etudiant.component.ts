import { FiliereService } from './../../../services/filiere.service';
import { Filiere } from './../../../models/filiere';
import { EtudiantService } from './../../../services/etudiant.service';
import { Etudiant } from './../../../models/etudiant';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-etudiant',
  templateUrl: './add-etudiant.component.html',
  styleUrls: ['./add-etudiant.component.css']
})
export class AddEtudiantComponent implements OnInit{

  etudiant:Etudiant={

    cin:'',
    nomComplet:"",
    dateNaissance:new Date(),
    filiere:{
      id:0,
    
    }
  }
  filieres:Filiere[]=[]

  constructor(
    private etudiantService: EtudiantService,
    private filiereService: FiliereService,private router:Router
  ) {}

  ngOnInit(): void {

    this.filiereService.getAllFiliere().subscribe((data)=>{

      this.filieres=data
    }
    )

  }

  addEtudiant(){
    this.etudiantService.addEtudiant(this.etudiant).subscribe((data)=>{
      console.log(data)
      alert("bien ajouté")
      this.router.navigate(['/etudiants'])
    })
  }

}
