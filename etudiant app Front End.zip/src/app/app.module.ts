import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListEtudiantComponent } from './components/etudiant-ui/list-etudiant/list-etudiant.component';
import { AddEtudiantComponent } from './components/etudiant-ui/add-etudiant/add-etudiant.component';
import { AddFiliereComponent } from './components/filiere-ui/add-filiere/add-filiere.component';
import { ListFiliereComponent } from './components/filiere-ui/list-filiere/list-filiere.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from "@angular/common/http";

@NgModule({
  declarations: [
    AppComponent,
    ListEtudiantComponent,
    AddEtudiantComponent,
    AddFiliereComponent,
    ListFiliereComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
