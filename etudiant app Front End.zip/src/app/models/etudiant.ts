import { Filiere } from "./filiere";

export interface Etudiant {

  id?: number,
  cin: string,
  nomComplet: string,
  dateNaissance: Date,
  filiere:Filiere


}
