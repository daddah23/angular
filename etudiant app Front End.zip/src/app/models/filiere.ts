export interface Filiere {

  id:Number,
  libelle?:string,

}
