import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Filiere } from '../models/filiere';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FiliereService {
  baseUrl:string="http://localhost:5050/universiapolis/filieres"
  constructor(private http:HttpClient) { }
getAllFiliere():Observable<Filiere[]>{

    return this.http.get<Filiere[]>(this.baseUrl);

  }

  getFiliereById(id:number):Observable<Filiere>{

    return this.http.get<Filiere>(`${this.baseUrl}/${id}`);

  }

  addFiliere(f:Filiere):Observable<Filiere>{
    return this.http.post<Filiere>(this.baseUrl,f);
  }

   updateFiliere(id: number, f: Filiere): Observable<Filiere> {
    return this.http.put<Filiere>(`${this.baseUrl}/${id}`, f);
  }


  deleteFiliere(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }

}
