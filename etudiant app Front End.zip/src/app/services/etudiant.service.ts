import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Etudiant } from '../models/etudiant';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EtudiantService {

  baseUrl:string="http://localhost:5050/universiapolis/etudiants"
  constructor(private http:HttpClient) { }

  getAllEtudiant():Observable<Etudiant[]>{

    return this.http.get<Etudiant[]>(this.baseUrl);

  }

  getEtudiantById(id:number):Observable<Etudiant>{

    return this.http.get<Etudiant>(`${this.baseUrl}/${id}`);

  }

  // Récupérer les étudiants par filière (en utilisant l'ID de la filière)
  getEtudiantByFiliere(filiereId: number): Observable<Etudiant[]> {
    return this.http.get<Etudiant[]>(`${this.baseUrl}/filiere/${filiereId}`);
  }

  addEtudiant(e:Etudiant):Observable<Etudiant>{
    return this.http.post<Etudiant>(this.baseUrl,e);
  }


updateEtudiant(id: number, e: Etudiant): Observable<Etudiant> {
  return this.http.put<Etudiant>(`${this.baseUrl}/${id}`, e);
}


deleteEtudiant(id: number): Observable<void> {
  return this.http.delete<void>(`${this.baseUrl}/${id}`);
}

}
