import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListEtudiantComponent } from './components/etudiant-ui/list-etudiant/list-etudiant.component';
import { AddEtudiantComponent } from './components/etudiant-ui/add-etudiant/add-etudiant.component';
import { ListFiliereComponent } from './components/filiere-ui/list-filiere/list-filiere.component';
import { AddFiliereComponent } from './components/filiere-ui/add-filiere/add-filiere.component';

const routes: Routes = [
  {path:"etudiants",component:ListEtudiantComponent},
  {path:"etudiants/add",component:AddEtudiantComponent},
  {path:"filieres",component:ListFiliereComponent},
  {path:"filieres/add",component:AddFiliereComponent},
  {path:"",redirectTo:"etudiants",pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
